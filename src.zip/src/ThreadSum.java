class ThreadSum extends Thread {
    private final int[] arr;
    private final int start;
    private final int end;
    private int sum = 0;

    // Construtor para a ThreadSum
    public ThreadSum(int[] arr, int start, int end) {
        this.arr = arr;
        this.start = start;
        this.end = end;
    }

    // Método run da thread que fará a soma dos elementos
    @Override
    public void run() {
        for (int i = start; i < end; i++) {
            sum += arr[i];
        }

        // Imprime a ID da thread e os valores que ela está somando
        System.out.println("Thread ID: " + Thread.currentThread().getId() + " somando de " + start + " a " + (end - 1));
        System.out.println("Valores somados: ");
        for (int i = start; i < end; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("\nSoma parcial: " + sum);
    }

    // Método para obter o valor da soma calculada pela thread
    public int getSum() {
        return sum;
    }
}