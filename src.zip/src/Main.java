import java.util.Random;

public class Main {
    public static void main(String[] args) {
        // Definindo o tamanho do array e o número de threads
        final int NUM_ELEMENTS = 20;  // Tamanho do array
        final int NUM_THREADS = 4;    // Número de threads (é importante que o número de elementos seja múltiplo de NUM_THREADS)

        // Criando o array
        int[] arr = new int[NUM_ELEMENTS];
        Random rand = new Random();

        // Preenchendo o array com números aleatórios entre 1 e 100
        for (int i = 0; i < NUM_ELEMENTS; i++) {
            arr[i] = rand.nextInt(100) + 1;  // Números entre 1 e 100
        }

        // Imprimir o array gerado
        System.out.println("Array de números gerados:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();

        // Determinar o tamanho de cada segmento do array
        int chunkSize = NUM_ELEMENTS / NUM_THREADS;

        // Array para armazenar as threads
        ThreadSum[] threads = new ThreadSum[NUM_THREADS];

        // Criando as threads
        for (int i = 0; i < NUM_THREADS; i++) {
            int start = i * chunkSize;
            int end = (i + 1) * chunkSize;
            threads[i] = new ThreadSum(arr, start, end);
        }

        // Iniciar as threads
        for (ThreadSum thread : threads) {
            thread.start();
        }

        // Aguardar a finalização das threads e somar os resultados
        int totalSum = 0;
        try {
            for (ThreadSum thread : threads) {
                thread.join();  // Espera a thread finalizar
                totalSum += thread.getSum();  // Soma o resultado da thread
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Imprimir o resultado final da soma
        System.out.println("Soma total: " + totalSum);
    }
}